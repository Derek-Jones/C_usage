perl -I../../r2/lib -I../../r2/blib/arch test_op3.pl "$@"
