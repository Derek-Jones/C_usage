typedef struct
{
	struct YYNODESTATE_block *blocks__;
	struct YYNODESTATE_push *push_stack__;
	int used__;

} YYNODESTATE;
