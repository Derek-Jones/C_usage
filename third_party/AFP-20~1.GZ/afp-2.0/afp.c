/*
 * $Id: afp.c,v 1.10 2001/08/22 23:57:54 condit Exp $
 *
 * Copyright (C) 1995 Regents of the University of Nevada
 *
 * See copyright.h for details.
 *
 */


#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <stdlib.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <assert.h>
#include "copyright.h"
#include "lcs.h"


#define AFP_VERSION "2.0"

#define DEFAULT_MIN_ACRONYM_LENGTH   3
#define DEFAULT_MAX_ACRONYM_LENGTH   10
#define DEFAULT_CONFIDENCE_ERROR_PCT 30

#define T_STOPWORD       's'
#define T_INITIAL_HYPH   'H'
#define T_FOLLOWING_HYPH 'h'
#define T_ACRONYM        'a'
#define T_NOTAWORD       'o'
#define T_NORMAL         'w'



static char rcsid[] = "$Id: afp.c,v 1.10 2001/08/22 23:57:54 condit Exp $";

typedef struct vector_values_st {
    int misses, stopcount, distance, size;
} VECTOR_VALUES;

static char *default_stopwords[] = {
    "of", "and", "for", "in", "a", "at", "the", "by", "to", "on", "or"
};
static int default_stopwords_size = 11;

char *prog;
static char **rejects, **stopwords;
static int min_acronym_length, max_acronym_length, confidence_error_pct;
static int rejects_size=0, stopwords_size=0;
static int fna_pos;



static void
usage()
{
    fprintf(stderr,
            "Usage: %s [-c confidence_error_pct] [-d definition_list]\n",
            prog);
    fprintf(stderr,
            "       [-r rejects_list] [-s stopwords_list]\n");
    fprintf(stderr,
            "       [-n min_acronym_length] [-x max_acronym_length]\n");
    fprintf(stderr,
            "       [-o output_file] document [document ...]\n");
    exit(1);
}


static void
version()
{
    fprintf(stderr, "%s version %s\n", prog, AFP_VERSION);
    fprintf(stderr, "Copyright (C) 1995 Regents of the University of Nevada\n");
    fprintf(stderr, "\nKazem Taghva, Allen Condit, and Julie Borsack\n");
    fprintf(stderr, "Text Retrieval Group\n");
    fprintf(stderr, "Information Science Research Institute\n");
    fprintf(stderr, "University of Nevada, Las Vegas\n");
    fprintf(stderr, "<isri-text@isri.unlv.edu>\n");
    exit(0);
}


static int
find_next_acronym(doc, acr_pos, acr_len)
    char *doc, **acr_pos;
    int *acr_len;
{
    /*
     * finds the next acronym candidate.  returns the position
     * in acr_pos and the length of the candidate in acr_len.
     * uses a finite state machine (FSM).  fna_pos is a global
     * which must be set to -1 before calling this routine for
     * the first time on a new document.
     */
    int state, upper_count;

    state = 0;
    *acr_pos = (char *)NULL;
    *acr_len = 0;

    /* start the machine */
    for (;;) {
        fna_pos++;
        if (doc[fna_pos] == '\0') {
            *acr_pos = (char *)NULL;
            *acr_len = 0;
            break;
        }
        switch (state) {
            case 0:
                /* in whitespace */
                if (ispunct(doc[fna_pos])) {
                    state = 2;
                } else if (isupper(doc[fna_pos])) {
                    *acr_pos = &doc[fna_pos];
                    upper_count = 0;
                    state = 3;
                }
                break;
            case 1:
                /* looking for whitespace */
                if (isspace(doc[fna_pos])) {
                    state = 0;
                }
                break;
            case 2:
                /* in punctuation after whitespace */
                if (isupper(doc[fna_pos])) {
                    *acr_pos = &doc[fna_pos];
                    upper_count = 0;
                    state = 3;
                } else if (isspace(doc[fna_pos])) {
                    state = 0;
                } else if (!ispunct(doc[fna_pos])) {
                    state = 1;
                }
                break;
            case 3:
                /*
                 * uppercase letters, but don't have min_acronym_length
                 * letters yet.
                 */
                upper_count++;
                if (isupper(doc[fna_pos])) {
                    if ((upper_count + 1) == min_acronym_length) {
                        state = 4;
                    }
                } else if (isspace(doc[fna_pos])) {
                    state = 0;
                } else if (!isupper(doc[fna_pos])) {
                    state = 1;
                }
                break;
            case 4:
                /*
                 * uppercase letters, and we've seen min_acronym_length
                 * of them, so this is an acronym candidate (provided
                 * there's not more than max_acronym_length uppercase
                 * letters).
                 */
                upper_count++;
                if (isspace(doc[fna_pos])) {
                    state = 6;
                } else if (ispunct(doc[fna_pos])) {
                    state = 5;
                } else if (isupper(doc[fna_pos]) &&
                           (upper_count == max_acronym_length)) {
                    state = 1;
                } else if (!isupper(doc[fna_pos])) {
                    state = 1;
                }
                break;
            case 5:
                /* in punctuation just after acronym */
                if (isspace(doc[fna_pos])) {
                    state = 6;
                } else if (!ispunct(doc[fna_pos])) {
                    state = 1;
                }
                break;
            case 6:
                /*
                 * final state.  whitespace located after acronym.
                 */
                *acr_len = upper_count;
                return(1);
                break;
            default:
                fprintf(stderr, "unknown state in find_next_acronym()\n");
                abort();
                break;
        }
    }
    return(1);
}


static int
is_all_uppercase_line(doc, pos)
    char *doc, *pos;
{
    /*
     * examines the line on which doc[pos] is located.  returns
     * true if the line has no lowercase letters, false otherwise.
     */
    char *p;

    /* find the beginning of the line */
    for (p=pos; (p != doc) && (*p != '\n'); --p);
    if (p != doc) {
        p++;
    }

    /* see if there's a lowercase letter on the line */
    for (; *p && (*p != '\n'); p++) {
        if (islower(*p)) {
            return(0);
        }
    }
    return(1);
}


static int
bsearch_word_cmp(keyval, datum)
    const void *keyval, *datum;
{
    return(strcasecmp((char *)keyval, *(char **)datum));
}

    
static int
is_reject(word)
    char *word;
{
    /*
     * returns true if word is in the rejects list, false if not.
     */
    if (rejects_size == 0) {
        return(0);
    }
    if (bsearch(word, rejects, rejects_size, sizeof(char *),
                bsearch_word_cmp)) {
        return(1);
    } else {
        return(0);
    }
}


static int
is_stopword(word)
    char *word;
{
    /*
     * returns true if word is in the stopwords list, false if not.
     */
    if (stopwords_size == 0) {
        return(0);
    }
    if (bsearch(word, stopwords, stopwords_size, sizeof(char *),
                bsearch_word_cmp)) {
        return(1);
    } else {
        return(0);
    }
}


static char *
strip_word(word)
    char *word;
{
    /*
     * removes all punctuation from beginning and end of word.
     * allocates space for the stripped word and returns a pointer
     * to the space.
     */
    char *sw, *p;

    if (!(sw = (char *)malloc(strlen(word)+1))) {
        perror(NULL);
        return(NULL);
    }

    /* strip off leading punct */
    for (p=word; *p && ispunct(*p); p++);
    strcpy(sw, p);

    /* strip off trailing punct */
    if (sw[0] != '\0') {
        for (p=&sw[strlen(sw)-1]; (p >= sw) && ispunct(*p); --p);
        if (p < sw) {
            sw[0] = '\0';
        } else {
            p++;
            *p = '\0';
        }
    }
    return(sw);
}

        
static char
word_type(word)
    char *word;
{
    /*
     * determines if word is a stopword, hyphenated word,
     * an acronym, a normal word, or a word with no letters
     * (not a word).  returns the appropriate T_ #define.
     */
    int word_len;
    char *p;
    
    /* see if it doesn't have any alphabetic characters */
    for (p=word; *p && !isalpha(*p); p++);
    if (!(*p)) {
        return(T_NOTAWORD);
    }
        
    /* see if it's a stopword */
    if (is_stopword(word)) {
        return(T_STOPWORD);
    }

    /* see if it's a hyphenated word */
    p = word;
    for (;;) {
        if (!(p = strchr(p, '-'))) {
            break;
        }
        if (p > word) {
            if (isalpha(*(p-1)) && isalpha(*(p+1))) {
                return(T_INITIAL_HYPH);
            }
        }
        p++;
    }

    /* see if it's an acronym */
    word_len = strlen(word);
    if ((word_len >= min_acronym_length) &&
        (word_len <= max_acronym_length)) {
        for (p=word; *p && isupper(*p); p++);
        if (!(*p)) {
            return(T_ACRONYM);
        }
    }

    /* otherwise it's a normal word */
    return(T_NORMAL);
}


static int
build_word_list(first_word, win_len, word_list)
    char *first_word;
    int win_len;
    char ***word_list;
{
    /*
     * builds an array of strings containing the words
     * in the window.  win_len is guaranteed to be correct
     * (i.e. we won't run into the beginning or end of the file).
     */
    int i;
    char ws;
    char *p, *q, *stripped_word;

    if (!(*word_list = (char **)calloc((win_len+1), sizeof(char *)))) {
        perror(NULL);
        return(0);
    }
    (*word_list)[win_len] = (char *)NULL;

    for (i=0,p=first_word; *p && (i<win_len); i++) {
        /* find end of word */
        for (q=p; *q && !isspace(*q); q++);
        assert(*q);

        /* strip it and add it to word_list */
        ws = *q;
        *q = '\0';
        if (!(stripped_word = strip_word(p))) {
            return(0);
        }
        *q = ws;
        (*word_list)[i] = stripped_word;

        /* scan forward for start of next word */
        for (p=q; *p && isspace(*p); p++);
    }

    return(1);
}


static int
free_word_list(word_list)
    char **word_list;
{
    int i;

    if (word_list) {
        for (i=0; word_list[i]; i++) {
            free(word_list[i]);
        }
        free(word_list);
    }
    return(1);
}


static int
find_hyph_leaders(word, hyph_leaders)
    char *word;
    char **hyph_leaders;
{
    /*
     * goes through a hyphenated word and returns
     * a string of the hyphenated leaders.  does not
     * include the first character.  so for example,
     * foo-bar-mumble would return "bm".
     */
    int hyphens, leaders;
    char *p;

    if (!(*hyph_leaders = (char *)malloc(strlen(word)+1))) {
        perror(NULL);
        return(0);
    }

    leaders = hyphens = 0;
    for (p=(word+1); *p; p++) {
        if (*p == '-') {
            hyphens = 1;
        } else if (hyphens) {
            if (isalpha(*p)) {
                (*hyph_leaders)[leaders++] = *p;
            }
            hyphens = 0;
        }
    }
    (*hyph_leaders)[leaders] = '\0';
    return(1);
}


static int
compute_vector_values(which_win, types, vector, vector_size, vv)
    char which_win;
    char *types;
    int *vector;
    int vector_size;
    VECTOR_VALUES *vv;
{
    /*
     * computes misses, stopcount, distance, and size of
     * a vector.  misses is the number of leaders in the definition
     * that didn't match a letter in the acronym.  stopcount is
     * the number of stopwords that occurred within the definition.
     * distance is the number of words between the edge of the
     * definition and the acronym.  size is the number of words
     * in the definition.
     */
    int i, first, last;

    for (first=0; (first < vector_size) && (vector[first] == 0); first++);
    for (last=(vector_size-1); (last > 0) && (vector[last] == 0); --last);

    vv->size = last - first + 1;

    if (which_win == 'L') {
        /* pre window...acronym is to right */
        vv->distance = (vector_size - 1) - last;
    } else {
        /* post window...acronym is to left */
        vv->distance = first;
    }

    vv->stopcount = vv->misses = 0;
    for (i=first; i<=last; i++) {
        if ((vector[i] > 0) && (types[i] == T_STOPWORD)) {
            vv->stopcount++;
        } else if ((vector[i] == 0) && (types[i] != T_STOPWORD) &&
                   (types[i] != T_FOLLOWING_HYPH)) {
            vv->misses++;
        }
    }

    return(1);
}


static int
compare_vectors(vv1, vv2)
    VECTOR_VALUES *vv1, *vv2;
{
    /*
     * decides which of two vectors (represented by their
     * VECTOR_VALUES) is more desirable.  returns -1 if
     * vv1 is better, and 1 if vv2 is better.
     */
    if (vv1->misses > vv2->misses) {
        return(1);
    } else if (vv1->misses < vv2->misses) {
        return(-1);
    }

    if (vv1->stopcount > vv2->stopcount) {
        return(1);
    } else if (vv1->stopcount < vv2->stopcount) {
        return(-1);
    }

    if (vv1->distance > vv2->distance) {
        return(1);
    } else if (vv1->distance < vv2->distance) {
        return(-1);
    }

    if (vv1->size > vv2->size) {
        return(1);
    } else if (vv1->size < vv2->size) {
        return(-1);
    }

    return(-1);
}


static int
satisfactory_vector_values(vv)
    VECTOR_VALUES *vv;
{
    /*
     * decides if the vector values for the chosen vector
     * in which_vector() constitute a reasonable vector.
     * what was happening is that an acronym would have one
     * possible vector, and that vector was not very good.
     * but since there were no other vectors to compare it
     * with, that vector was chosen by default as the one
     * to build the definition with.  this routine is an attempt
     * to ensure some basic level of quality of the vector
     * used to form the definition.  this routine could benefit
     * from some more careful analysis of the output.
     */
    if ((vv->misses > 2) || (vv->stopcount > 3) || (vv->distance > 2)) {
        return(0);
    }
    return(1);
}


static int
which_vector(lcs_vectors, num_lcs_vectors, vector_size,
             use_vector, which_win, types)
    int **lcs_vectors;
    int num_lcs_vectors, vector_size;
    int *use_vector;
    char which_win;
    char *types;
{
    /*
     * decides which vector in lcs_vectors should be
     * used to form the definition for the acronym.
     * sets use_vector to the index in lcs_vectors
     * of the vector to be used.  could return -1 if
     * none of the vectors are good enough to be used,
     * but right now it always chooses one of the
     * given vectors.
     */
    VECTOR_VALUES *vvs;
    int i, result;

    assert(num_lcs_vectors != 0);

    if (!(vvs = (VECTOR_VALUES *)
          malloc(num_lcs_vectors * sizeof(VECTOR_VALUES)))) {
        perror(NULL);
        return(0);
    }

    *use_vector = 0;
    for (i=0; i<num_lcs_vectors; i++) {
        if (!compute_vector_values(which_win, types,
                                   lcs_vectors[i], vector_size, &(vvs[i]))) {
            return(0);
        }
        if (i != 0) {
            result = compare_vectors(&(vvs[*use_vector]), &(vvs[i]));
            if (result == 0) {
                /* error */
                return(0);
            } else if (result > 0) {
                *use_vector = i;
            }
        }
    }

    if (!satisfactory_vector_values(&(vvs[*use_vector]))) {
        *use_vector = -1;
    }

    free(vvs);
    return(1);
}


static int
build_defn(vector, vector_size, types, word_list, def)
    int *vector;
    int vector_size;
    char *types;
    char **word_list;
    char **def;
{
    /*
     * given the vector, vector_size, and the types array, this
     * routine goes through the word_list and builds the definition
     * string.  returns it in def.
     */
    int i, first, last, extra_hyph;

    extra_hyph = 0;
    for (first=0; (first < vector_size) && (vector[first] == 0); first++) {
        if (types[first] == T_FOLLOWING_HYPH) {
            extra_hyph++;
        }
    }
    for (last=(vector_size-1); (last >= 0) && (vector[last] == 0); --last);

    *def = (char *)NULL;
    for (i=first; i<=last; i++) {
        if (types[i] == T_FOLLOWING_HYPH) {
            extra_hyph++;
            continue;
        }
        if (!(*def)) {
            if (!((*def) =
                  (char *)malloc(strlen(word_list[i-extra_hyph])+1))) {
                perror(NULL);
                return(0);
            }
            strcpy(*def, word_list[i-extra_hyph]);
        } else {
            if (!((*def) = (char *)
                  realloc(*def, strlen(*def) +
                          strlen(word_list[i-extra_hyph]) + 2))) {
                perror(NULL);
                return(0);
            }
            strcat(*def, " ");
            strcat(*def, word_list[i-extra_hyph]);
        }
    }
    return(1);
}


static int
process_window(acronym, first_word, win_len, def, which_win)
    char *acronym, *first_word;
    int win_len;
    char **def;
    char which_win;
{
    /*
     * try to determine the acronym's definition by analyzing
     * words in the acronym's window.  returns the definition
     * string in def if found.
     */
    char *p, *leaders, *types, *hyph_leaders;
    char **word_list;
    int i, m, n, lt_size, lt_index, lcs_length, num_lcs_vectors;
    int **b=(int **)NULL;
    int **lcs_vectors;
    int use_vector;
    float confidence;

    /* build a list of the words in the window */
    if (!build_word_list(first_word, win_len, &word_list)) {
        return(0);
    }

    /*
     * make sure the acronym we're trying to define does
     * not also occur in the window.
     */
    for (i=0; i<win_len; i++) {
        if (!strcasecmp(acronym, word_list[i])) {
            if (!free_word_list(word_list)) {
                return(0);
            }
            return(1);
        }
    }

    lt_size = win_len;
    if (!(leaders = (char *)malloc(lt_size+1)) ||
        !(types = (char *)malloc(lt_size+1))) {
        perror(NULL);
        return(0);
    }

    lt_index = -1;
    for (i=0; i<win_len; i++) {
        assert(word_list[i]);
        types[++lt_index] = word_type(word_list[i]);
        if (types[lt_index] == T_NOTAWORD) {
            leaders[lt_index] = '.';
        } else {
            leaders[lt_index] = tolower(word_list[i][0]);
        }
        if (types[lt_index] == T_INITIAL_HYPH) {
            if (!find_hyph_leaders(word_list[i], &hyph_leaders)) {
                return(0);
            }
            lt_size += strlen(hyph_leaders);
            if (!(leaders = (char *)realloc(leaders, (lt_size+1))) ||
                !(types = (char *)realloc(types, (lt_size+1)))) {
                perror(NULL);
                return(0);
            }
            for (p=hyph_leaders; *p; p++) {
                leaders[++lt_index] = tolower(*p);
                types[lt_index] = T_FOLLOWING_HYPH;
            }
            free(hyph_leaders);
        }
    }
    assert((lt_index+1) == lt_size);

    leaders[lt_size] = types[lt_size] = '\0';
    m = strlen(acronym);
    n = strlen(leaders);

    /*
     * build the lcs matrix for the acronym and the leaders array.
     * this will give us the basic information necessary to construct
     * all the definition possibilities.
     */
    if (!build_lcs_matrix(acronym, leaders, m, n, &b, &lcs_length)) {
        return(0);
    }
    assert(b);

    confidence = (float)lcs_length / (float)m *
        ((confidence_error_pct / 100.0) + 1);

    if (confidence >= 1.0) {
        /*
         * parse the lcs matrix and build a list of vectors
         * for possible sequences of words for the definition.
         */
        if (!parse_lcs_matrix(b, 1, 1, m, n, lcs_length,
                              &lcs_vectors, &num_lcs_vectors)) {
            return(0);
        }

        assert(num_lcs_vectors);
        /*
         * decide which vector to use to form the definition.
         */
        if (!which_vector(lcs_vectors, num_lcs_vectors, n, &use_vector,
                          which_win, types)) {
            return(0);
        }

        if (use_vector != -1) {
            /*
             * take the selected vector and build the definition.
             */
            if (!build_defn(lcs_vectors[use_vector], n,
                            types, word_list, def)) {
                return(0);
            }
        }

        /* free up the vectors */
        for (i=0; i<num_lcs_vectors; i++) {
            free(lcs_vectors[i]);
        }
        free(lcs_vectors);
    }

    /* clean up */
    for (i=0; i<=m; i++) {
        free(b[i]);
    }
    free(b);

    if (!free_word_list(word_list)) {
        return(0);
    }
    free(leaders);
    free(types);
    return(1);
}


static int
pre_window(acronym, doc, pos, win_len, def)
    char *acronym, *doc, *pos;
    int win_len;
    char **def;
{
    /*
     * handles the window that is before the acronym.
     */
    char *p;
    int i;

    /*
     * find the beginning of the window, or the
     * beginning of the file, whichever comes first.
     */
    for (p=pos; (p != doc) && !isspace(*p); --p);
    for (i=0; (p != doc) && (i<win_len); i++) {
        for (; (p != doc) && isspace(*p); --p);
        for (; (p != doc) && !isspace(*p); --p);
    }

    if (i < 3) {
        /* too few words in window...requires at least 2 words */
        return(1);
    }

    /*
     * this bit of goofyness is necessary to get the
     * p pointer and win_len correct, even if the window
     * runs into the beginning of the file.  if that does
     * happen, win_len gets shortened to however many words
     * are there.
     */
    if (p != doc) {
        p++;
    } else {
        win_len = i;
        if (isspace(*p)) {
            p++;
            if (isspace(*p)) {
                --win_len;
                for (p++; isspace(*p); p++);
            }
        }
    }

    /*
     * process the window.  p should be pointing at
     * the first word of the window.
     */
    if (!process_window(acronym, p, win_len, def, 'L')) {
        return(0);
    }

    return(1);
}


static int
post_window(acronym, doc, pos, win_len, def)
    char *acronym, *doc, *pos;
    int win_len;
    char **def;
{
    /*
     * handles the window that is after the acronym.
     */
    char *p, *q;
    int i;

    /* scan forwards to first word of post window */
    for (p=pos; *p && !isspace(*p); p++);
    for (; *p && isspace(*p); p++);

    /*
     * make sure there are actually win_len words in
     * the window.  if not, shorten win_len to however
     * many words are there (we ran into the end of the file).
     */
    for (i=0,q=p; *q && (i<win_len); i++) {
        for (; *q && isspace(*q); q++);
        for (; *q && !isspace(*q); q++);
    }
    if (i < 3) {
        /* too few words in window...requires at least 2 words */
        return(1);
    }
    if (!(*q)) {
        win_len = i-1;
    }

    /*
     * process the window.  p should be pointing at
     * the first word of the window.
     */
    if (!process_window(acronym, p, win_len, def, 'R')) {
        return(0);
    }

    return(1);
}


static int
in_database(acronym, def)
    char *acronym;
    char **def;
{
    /*
     * looks to see if the acronym is in the predefined
     * database of acronyms and their definitions.
     *
     * not implemented yet.
     */
    return(1);
}


static int
process_document(doc, out_st)
    char *doc;
    FILE *out_st;
{
    int i, len = 0;
    char *acr_buf;
    char *acr_def=NULL;
    char *pos;

    if (!(acr_buf = (char *)malloc(max_acronym_length+1))) {
        perror(NULL);
        return(0);
    }

    fna_pos = -1;

    for (;;) {
        if (!find_next_acronym(doc, &pos, &len)) {
            return(0);
        }
        if (!pos) {
            /* no more acronyms in document */
            break;
        }
        if (is_all_uppercase_line(doc, pos)) {
            /* skip it if all letters on line are uppercase */
            continue;
        }

        /* reject this acronym if it's in our reject list */
        if (is_reject(acr_buf)) {
            continue;
        }

        for (i=0; i<len; i++) {
            acr_buf[i] = pos[i];
        }
        acr_buf[len] = '\0';

        /*
         * process the acronym...try to find its definition.
         * if checking the pre and post windows fails, check
         * the predefined database (if it exists) for a
         * definition as a last resort.
         */
        if (!pre_window(acr_buf, doc, pos, (len*2)+1, &acr_def)) {
            return(0);
        }
        if (!acr_def) {
            if (!post_window(acr_buf, doc, pos, (len*2)+1, &acr_def)) {
                return(0);
            }
            if (!acr_def) {
                if (!in_database(acr_buf, &acr_def)) {
                    return(0);
                }
                if (!acr_def) {
                    continue;
                }
            }
        }

        fprintf(out_st, "%10s  :  %s\n", acr_buf, acr_def);
        free(acr_def);
        acr_def = NULL;
    }
    free(acr_buf);
    return(1);
}


static int
qsort_ext_list_compare(a, b)
    const void *a, *b;
{
    return(strcmp(*(char **)a, *(char **)b));
}


static int
build_ext_list(fn, list, size)
    char *fn;
    char ***list;
    int *size;
{
    /*
     * takes a filename, opens it, and reads in a list of
     * words into 'list' and setting 'size'.  allocates all
     * necessary memory.  also sorts the words in ascending
     * alphabetic order.
     */
    int list_size;
    int list_index = -1;
    int buf_len;
    FILE *file_st;
    char buf[BUFSIZ];

    if (!(file_st = fopen(fn, "r"))) {
        perror(fn);
        return(0);
    }

    list_size = 32;
    if (!(*list = (char **)malloc(list_size * sizeof(char *)))) {
        perror(NULL);
        return(0);
    }

    for (;;) {
        if (!fgets(buf, BUFSIZ, file_st)) {
            fclose(file_st);
            break;
        }
        list_index++;
        if (list_index == list_size) {
            list_size += 32;
            if (!(*list = (char **)realloc(*list,
                                           list_size * sizeof(char *)))) {
                perror(NULL);
                return(0);
            }
        }
        buf_len = strlen(buf);
        buf[--buf_len] = '\0';  /* trash newline */
        if (!((*list)[list_index] = (char *)malloc(buf_len + 1))) {
            perror(NULL);
            return(0);
        }
        strcpy((*list)[list_index], buf);
    }
    *size = list_index+1;

    qsort(*list, *size, sizeof(char *), qsort_ext_list_compare);

    return(1);
}


int
main(argc, argv)
    int argc;
    char *argv[];
{
    char *doc, *p;
    struct stat stat_buf;
    int c, in_fd, nread;
    int doc_end, doc_unused, doc_size;
    extern char *optarg;
    extern int optind;
    FILE *out_st;

    if ((p = strrchr(argv[0], '/'))) {
        p++;
    } else {
        p = argv[0];
    }
    if (!(prog = (char *)malloc(strlen(p)+1))) {
        perror(NULL);
        exit(1);
    }
    strcpy(prog, p);
        
    min_acronym_length = DEFAULT_MIN_ACRONYM_LENGTH;
    max_acronym_length = DEFAULT_MAX_ACRONYM_LENGTH;
    confidence_error_pct = DEFAULT_CONFIDENCE_ERROR_PCT;
    stopwords = default_stopwords;
    stopwords_size = default_stopwords_size;
    out_st = stdout;

    while ((c = getopt(argc, argv, "hvc:d:r:s:n:x:o:")) != -1) {
        switch (c) {
            case 'c':
                /* confidence error percentage */
                confidence_error_pct = atoi(optarg);
                if ((confidence_error_pct < 0) ||
                    (confidence_error_pct > 100)) {
                    fprintf(stderr, "percentage must be from 0 to 100.\n");
                    exit(1);
                }
                break;
            case 'd':
                /* external acronym/definition list */
                /* not implemented yet. */
                break;
            case 'r':
                /* acronym rejects list */
                if (!build_ext_list(optarg, &rejects, &rejects_size)) {
                    exit(1);
                }
                break;
            case 's':
                /* stopwords list */
                if (!build_ext_list(optarg, &stopwords, &stopwords_size)) {
                    exit(1);
                }
                break;
            case 'n':
                /* minimum length for an acronym */
                min_acronym_length = atoi(optarg);
                if ((min_acronym_length < 2) ||
                    (min_acronym_length > 50)) {
                    fprintf(stderr,
                            "minimum acronym length must be from 2 to 50.\n");
                    exit(1);
                }
                break;
            case 'x':
                /* maximum length for an acronym */
                max_acronym_length = atoi(optarg);
                if ((max_acronym_length < 2) ||
                    (max_acronym_length > 50)) {
                    fprintf(stderr,
                            "maximum acronym length must be from 2 to 50.\n");
                    exit(1);
                }
                break;
            case 'o':
                /* output file name */
                if (!(out_st = fopen(optarg, "w"))) {
                    perror(optarg);
                    exit(1);
                }
                break;
            case 'v':
                version();
                break;
            case 'h':
            case '?':
            default:
                usage();
                break;
        }
    }

    if (optind == argc) {
        /* read from stdin */
        doc_size = doc_unused = BUFSIZ;
        doc_end = 0;
        if (!(doc = (char *)malloc(doc_size+1))) {
            perror(NULL);
            exit(1);
        }
        for (;;) {
            nread = read(0, &doc[doc_end], doc_unused);
            if (nread == -1) {
                perror(NULL);
                exit(1);
            } else if (nread == 0) {
                /* eof */
                doc[doc_end] = '\0';
                break;
            } else {
                doc_end += nread;
                doc_unused -= nread;
            }
            if (doc_unused == 0) {
                doc_size += BUFSIZ;
                doc_unused = BUFSIZ;
                if (!(doc = (char *)realloc(doc, doc_size+1))) {
                    perror(NULL);
                    exit(1);
                }
            }
        }

        if (!process_document(doc, out_st)) {
            exit(1);
        }
        free(doc);

    } else {
        /* read from file(s) */
        for (; optind<argc; optind++) {
            if ((in_fd = open(argv[optind], O_RDONLY, 0)) == -1) {
                perror(argv[optind]);
                continue;
            }
            if (stat(argv[optind], &stat_buf) == -1) {
                perror(argv[optind]);
                continue;
            }
            if (!(doc = (char *)malloc(stat_buf.st_size + 1))) {
                perror(NULL);
                exit(1);
            }
            nread = read(in_fd, doc, stat_buf.st_size);
            if (nread == -1) {
                perror(argv[optind]);
                exit(1);
            } else if (nread != stat_buf.st_size) {
                fprintf(stderr, "%s: couldn't finish reading file\n",
                        argv[optind]);
            }
            doc[nread] = '\0';
            close(in_fd);

            if (!process_document(doc, out_st)) {
                exit(1);
            }
            free(doc);
        }
    }

    fclose(out_st);
    exit(0);
}
