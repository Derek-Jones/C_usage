/*
 * $Id: lcs.c,v 1.4 2001/08/22 23:57:54 condit Exp $
 *
 * Copyright (C) 1995 Regents of the University of Nevada
 *
 * See copyright.h for details.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#define A_DIAG 1
#define A_UP   2
#define A_LEFT 3

static char rcsid[] = "$Id: lcs.c,v 1.4 2001/08/22 23:57:54 condit Exp $";

typedef struct b_matrix_entry_st {
    int i, j;
    struct b_matrix_entry_st *next;
} B_MATRIX_ENTRY;




int
build_lcs_matrix(s1, s2, m, n, b, lcs_length)
    char *s1, *s2;
    int m, n;
    int ***b;
    int *lcs_length;
{
    char *x, *y;
    int **c;
    int i, j;

    /* make sure both strings are all lowercase */
    if (!(x = (char *)malloc(m+1)) ||
        !(y = (char *)malloc(n+1))) {
        perror(NULL);
        return(0);
    }
    for (i=0; i<m; i++) {
        x[i] = tolower(s1[i]);
    }
    for (i=0; i<n; i++) {
        y[i] = tolower(s2[i]);
    }

    /* allocate the b and c matrices */
    if (!(*b = (int **)malloc((m+1) * sizeof(int *))) ||
        !(c = (int **)malloc((m+1) * sizeof(int *)))) {
        perror(NULL);
        return(0);
    }
    for (i=0; i<=m; i++) {
        if (!((*b)[i] = (int *)malloc((n+1) * sizeof(int))) ||
            !(c[i] = (int *)malloc((n+1) * sizeof(int)))) {
            perror(NULL);
            return(0);
        }
    }

    /* initialize them */
    for (i=0; i<=m; i++) {
        c[i][0] = 0;
    }
    for (j=1; j<=n; j++) {
        c[0][j] = 0;
    }

    /* build the matrices */
    for (i=1; i<=m; i++) {
        for (j=1; j<=n; j++) {
            if (x[i-1] == y[j-1]) {
                c[i][j] = c[i-1][j-1] + 1;
                (*b)[i][j] = A_DIAG;
            } else if (c[i-1][j] >= c[i][j-1]) {
                c[i][j] = c[i-1][j];
                (*b)[i][j] = A_UP;
            } else {
                c[i][j] = c[i][j-1];
                (*b)[i][j] = A_LEFT;
            }
        }
    }

    *lcs_length = c[m][n];

    free(x);
    free(y);
    for (i=0; i<=m; i++) {
        free(c[i]);
    }
    free(c);
    return(1);
}


static int
save_vector(stack, vector_list, vector_list_length, n)
    B_MATRIX_ENTRY *stack;
    int ***vector_list;
    int *vector_list_length;
    int n;
{
    /*
     * pops b[i][j] values off the stack and builds the
     * vector for the acronym definition.  vector length
     * is the length of the leaders array, and each v[i]
     * corresponds with leaders[i] and is nonzero if leaders[i]
     * is a letter in the acronym.  after building the vector,
     * it adds it to vector_list and increments vector_list_length.
     */
    int i, vector_index;
    int *vector;
    B_MATRIX_ENTRY *s;

    if (!(vector = (int *)malloc(n * sizeof(int)))) {
        perror(NULL);
        return(0);
    }
    for (i=0; i<n; i++) {
        vector[i] = 0;
    }

    for (s = stack; s; s = s->next) {
        vector_index = s->j - 1;
        assert((vector_index >= 0) && (vector_index < n));
        vector[vector_index] = s->i;
    }

    if (*vector_list_length == 0) {
        (*vector_list_length)++;
        if (!(*vector_list = (int **)
              malloc((*vector_list_length) * sizeof(int *)))) {
            perror(NULL);
            return(0);
        }
    } else {
        (*vector_list_length)++;
        if (!(*vector_list = (int **)
              realloc(*vector_list, ((*vector_list_length) *
                                     sizeof(int *))))) {
            perror(NULL);
            return(0);
        }
    }
    (*vector_list)[(*vector_list_length) - 1] = vector;
    return(1);
}


int
parse_lcs_matrix(b, start_i, start_j, m, n, lcs_length,
                 lcs_vectors, num_lcs_vectors)
    int **b;
    int start_i, start_j, m, n, lcs_length;
    int ***lcs_vectors;
    int *num_lcs_vectors;
{
    /*
     * builds a list of LCS vectors, returning them in 'lcs_vectors'
     * and the number of them in 'num_lcs_vectors'.
     */
    static B_MATRIX_ENTRY *stack;
    B_MATRIX_ENTRY *node, *cur;
    int i, j;

    if ((start_i == 1) && (start_j == 1)) {
        stack = (B_MATRIX_ENTRY *)NULL;
        *lcs_vectors = (int **)NULL;
        *num_lcs_vectors = 0;
    }

    for (i=start_i; i<=m; i++) {
        for (j=start_j; j<=n; j++) {
            if (b[i][j] == A_DIAG) {
                if (!(node =
                      (B_MATRIX_ENTRY *)malloc(sizeof(B_MATRIX_ENTRY)))) {
                    perror(NULL);
                    return(0);
                }
                node->i = i;
                node->j = j;
                node->next = stack;
                stack = node;

                if (lcs_length == 1) {
                    /* save lcs in vector list */
                    if (!save_vector(stack, lcs_vectors,
                                     num_lcs_vectors, n)) {
                        return(0);
                    }
                } else {
                    if (!parse_lcs_matrix(b, i+1, j+1, m, n, lcs_length-1,
                                          lcs_vectors, num_lcs_vectors)) {
                        return(0);
                    }
                }

                cur = stack;
                if (cur) {
                    stack = cur->next;
                    free(cur);
                }
            }
        }
    }
    return(1);
}
