/*
 * $Id: lcs.h,v 1.2 2001/08/22 23:57:55 condit Exp $
 *
 * Copyright (C) 1995 Regents of the University of Nevada
 *
 * See copyright.h for details.
 *
 */

int build_lcs_matrix(/* char *x, *y; int m, n; int ***b; int *lcs_length */);
int parse_lcs_matrix(/* int **b; int start_i, start_j, m, n, lcs_length;
                        int ***lcs_vectors; int *num_lcs_vectors */);
